# Krishi Guard AI — SIH 2026 (PS 26131)

Demo prototype. Next.js App Router + TypeScript + Tailwind CSS + Recharts + Lucide.
All AI, payment, booking and login flows are simulated (no paid APIs, no backend).

## Setup
npm install
npm run dev

Open http://localhost:3000

## Demo login
Mobile: 9999999999
Password: demo123
