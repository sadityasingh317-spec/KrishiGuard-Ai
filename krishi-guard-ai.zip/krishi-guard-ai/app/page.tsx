import Link from "next/link";
import { ShieldCheck, ScanLine, TrendingUp, Landmark, ArrowRight, Sprout } from "lucide-react";

const features = [
  { icon: ScanLine, title: "Disease detection", desc: "Upload a leaf photo and get an instant AI diagnosis with treatment steps." },
  { icon: TrendingUp, title: "Risk prediction", desc: "Weather and soil signals combine into a 7-day outbreak risk score." },
  { icon: Landmark, title: "Government schemes", desc: "Discover subsidies, insurance and credit schemes you're eligible for." },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-leaf-50/40">
      <header className="flex items-center justify-between px-6 py-5 md:px-12">
        <div className="flex items-center gap-2">
          <div className="rounded-xl bg-leaf-600 p-2"><Sprout className="h-5 w-5 text-white" /></div>
          <span className="font-display text-lg font-semibold text-leaf-900">Krishi Guard AI</span>
        </div>
        <Link href="/login" className="btn-primary">Login</Link>
      </header>

      <section className="mx-auto max-w-5xl px-6 pt-10 pb-16 text-center md:pt-16">
        <span className="demo-tag mb-5">SIH 2026 · Problem Statement 26131 · Prototype</span>
        <h1 className="font-display text-4xl font-semibold leading-tight text-leaf-900 md:text-5xl">
          Catch crop disease early.<br />Protect every harvest.
        </h1>
        <p className="mx-auto mt-4 max-w-xl text-leaf-700">
          Krishi Guard AI turns a phone camera and local weather data into early warnings,
          treatment guidance and market insight for farmers.
        </p>
        <div className="mt-8 flex justify-center gap-3">
          <Link href="/login" className="btn-primary flex items-center gap-2">
            Try the demo <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <p className="mt-3 text-xs text-leaf-500">Demo login — mobile 9999999999, password demo123</p>
      </section>

      <section className="mx-auto max-w-5xl px-6 pb-20">
        <div className="grid gap-5 md:grid-cols-3">
          {features.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="card">
              <div className="mb-3 w-fit rounded-xl bg-leaf-100 p-2.5"><Icon className="h-5 w-5 text-leaf-700" /></div>
              <h3 className="font-display font-semibold text-leaf-900">{title}</h3>
              <p className="mt-1 text-sm text-leaf-700">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-leaf-100 px-6 py-6 text-center text-xs text-leaf-500">
        <div className="flex items-center justify-center gap-1.5"><ShieldCheck className="h-3.5 w-3.5" /> Prototype for evaluation — all AI, payment and booking flows are simulated.</div>
      </footer>
    </div>
  );
}
