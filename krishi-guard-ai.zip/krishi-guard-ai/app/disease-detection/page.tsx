"use client";

import { useState } from "react";
import ProtectedShell from "@/components/ProtectedShell";
import DemoTag from "@/components/DemoTag";
import { UploadCloud, ScanLine, Loader2 } from "lucide-react";
import { diseaseResults } from "@/lib/mockData";

export default function DiseaseDetection() {
  const [preview, setPreview] = useState<string | null>(null);
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<typeof diseaseResults[number] | null>(null);

  function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setPreview(URL.createObjectURL(file));
    setResult(null);
  }

  function runScan() {
    setScanning(true);
    setTimeout(() => {
      setResult(diseaseResults[Math.floor(Math.random() * diseaseResults.length)]);
      setScanning(false);
    }, 1400);
  }

  const severityColor: Record<string, string> = {
    Low: "bg-leaf-100 text-leaf-700",
    Moderate: "bg-wheat/40 text-soil",
    High: "bg-red-100 text-red-700",
  };

  return (
    <ProtectedShell title="Disease Detection">
      <div className="mb-4"><DemoTag label="AI result is simulated for demo" /></div>
      <div className="grid gap-5 lg:grid-cols-2">
        <div className="card">
          <h3 className="mb-3 font-display font-semibold text-leaf-900">Upload crop leaf photo</h3>
          <label className="flex h-56 cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-leaf-200 bg-leaf-50/50 text-leaf-600 hover:bg-leaf-50">
            {preview ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={preview} alt="Leaf preview" className="h-full w-full rounded-xl object-cover" />
            ) : (
              <>
                <UploadCloud className="mb-2 h-8 w-8" />
                <span className="text-sm">Tap to upload an image</span>
              </>
            )}
            <input type="file" accept="image/*" className="hidden" onChange={onFile} />
          </label>
          <button
            disabled={!preview || scanning}
            onClick={runScan}
            className="btn-primary mt-4 flex w-full items-center justify-center gap-2"
          >
            {scanning ? <Loader2 className="h-4 w-4 animate-spin" /> : <ScanLine className="h-4 w-4" />}
            {scanning ? "Analyzing…" : "Detect disease"}
          </button>
        </div>

        <div className="card">
          <h3 className="mb-3 font-display font-semibold text-leaf-900">Diagnosis</h3>
          {!result && !scanning && (
            <p className="text-sm text-leaf-500">Upload a photo and run detection to see results here.</p>
          )}
          {scanning && <p className="text-sm text-leaf-500">Running AI analysis on the sample image…</p>}
          {result && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-display text-lg font-semibold text-leaf-900">{result.disease}</span>
                <span className={`badge ${severityColor[result.severity]}`}>{result.severity} severity</span>
              </div>
              <p className="text-sm text-leaf-700">Crop: <b>{result.crop}</b> · Confidence: <b>{result.confidence}%</b></p>
              <p className="text-sm text-leaf-700">{result.symptoms}</p>
              <a href="/recommendations" className="btn-outline mt-2 inline-block">View treatment recommendations</a>
            </div>
          )}
        </div>
      </div>
    </ProtectedShell>
  );
}
