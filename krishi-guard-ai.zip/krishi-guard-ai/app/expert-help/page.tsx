"use client";

import { useState } from "react";
import ProtectedShell from "@/components/ProtectedShell";
import DemoTag from "@/components/DemoTag";
import { experts } from "@/lib/mockData";
import { UserCircle2, CheckCircle2 } from "lucide-react";

export default function ExpertHelp() {
  const [requested, setRequested] = useState<string[]>([]);

  return (
    <ProtectedShell title="Expert Help">
      <div className="mb-4"><DemoTag label="Consultation booking is simulated" /></div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {experts.map((e) => (
          <div key={e.name} className="card">
            <div className="mb-2 flex items-center gap-3">
              <div className="rounded-full bg-leaf-100 p-2"><UserCircle2 className="h-6 w-6 text-leaf-700" /></div>
              <div>
                <h3 className="font-medium text-leaf-900">{e.name}</h3>
                <p className="text-xs text-leaf-500">{e.role} · {e.exp}</p>
              </div>
            </div>
            <span className={`badge ${e.available ? "bg-leaf-100 text-leaf-700" : "bg-gray-100 text-gray-500"}`}>
              {e.available ? "Available today" : "Unavailable"}
            </span>
            {requested.includes(e.name) ? (
              <div className="btn-outline mt-3 flex w-full items-center justify-center gap-2 !text-leaf-600">
                <CheckCircle2 className="h-4 w-4" /> Request sent
              </div>
            ) : (
              <button
                disabled={!e.available}
                onClick={() => setRequested((r) => [...r, e.name])}
                className="btn-primary mt-3 w-full"
              >
                Request consultation
              </button>
            )}
          </div>
        ))}
      </div>
    </ProtectedShell>
  );
}
