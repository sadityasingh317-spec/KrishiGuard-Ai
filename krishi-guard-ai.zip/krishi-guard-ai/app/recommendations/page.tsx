"use client";

import { useState } from "react";
import ProtectedShell from "@/components/ProtectedShell";
import { recommendations } from "@/lib/mockData";
import { Leaf, Bug, CheckCircle2 } from "lucide-react";

export default function Recommendations() {
  const [tab, setTab] = useState<"organic" | "ipm">("organic");

  return (
    <ProtectedShell title="Recommendations">
      <div className="mb-5 inline-flex rounded-xl border border-leaf-200 bg-white p-1">
        <button
          onClick={() => setTab("organic")}
          className={`flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-medium ${tab === "organic" ? "bg-leaf-600 text-white" : "text-leaf-700"}`}
        >
          <Leaf className="h-4 w-4" /> Organic
        </button>
        <button
          onClick={() => setTab("ipm")}
          className={`flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-medium ${tab === "ipm" ? "bg-leaf-600 text-white" : "text-leaf-700"}`}
        >
          <Bug className="h-4 w-4" /> IPM (Integrated Pest Mgmt)
        </button>
      </div>

      <div className="card">
        <h3 className="mb-4 font-display font-semibold text-leaf-900">
          {tab === "organic" ? "Organic treatment plan" : "Integrated pest management plan"}
        </h3>
        <ul className="space-y-3">
          {recommendations[tab].map((step) => (
            <li key={step} className="flex items-start gap-3 rounded-xl bg-leaf-50 p-3">
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-leaf-600" />
              <span className="text-sm text-leaf-800">{step}</span>
            </li>
          ))}
        </ul>
        <p className="mt-4 text-xs text-leaf-500">Based on the most recent disease detection result. Consult a local expert before applying chemical treatments.</p>
      </div>
    </ProtectedShell>
  );
}
