"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Sprout, Lock, Phone } from "lucide-react";
import { login, DEMO_MOBILE, DEMO_PASSWORD } from "@/lib/auth";

export default function LoginPage() {
  const router = useRouter();
  const [mobile, setMobile] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (login(mobile, password)) {
      router.push("/dashboard");
    } else {
      setError("Invalid credentials. Use the demo login shown below.");
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-leaf-50/40 px-4">
      <div className="w-full max-w-sm">
        <Link href="/" className="mb-6 flex items-center justify-center gap-2">
          <div className="rounded-xl bg-leaf-600 p-2"><Sprout className="h-5 w-5 text-white" /></div>
          <span className="font-display text-lg font-semibold text-leaf-900">Krishi Guard AI</span>
        </Link>
        <div className="card">
          <h1 className="font-display text-xl font-semibold text-leaf-900">Welcome back</h1>
          <p className="mb-5 text-sm text-leaf-600">Sign in to your demo farmer account</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="mb-1 block text-sm font-medium text-leaf-800">Mobile number</label>
              <div className="relative">
                <Phone className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-leaf-400" />
                <input
                  className="input pl-9"
                  inputMode="numeric"
                  maxLength={10}
                  placeholder="9999999999"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                />
              </div>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-leaf-800">Password</label>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-leaf-400" />
                <input
                  className="input pl-9"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>
            {error && <p className="text-sm text-red-600">{error}</p>}
            <button type="submit" className="btn-primary w-full">Login</button>
          </form>

          <div className="mt-5 rounded-xl bg-leaf-50 p-3 text-xs text-leaf-700">
            Demo credentials — Mobile: <b>{DEMO_MOBILE}</b> · Password: <b>{DEMO_PASSWORD}</b>
          </div>
        </div>
      </div>
    </div>
  );
}
