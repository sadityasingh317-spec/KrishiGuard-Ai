"use client";

import ProtectedShell from "@/components/ProtectedShell";
import DemoTag from "@/components/DemoTag";
import { riskTrend } from "@/lib/mockData";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { CloudRain, Thermometer, Droplets } from "lucide-react";

const factors = [
  { icon: CloudRain, label: "Rainfall (7-day)", value: "68 mm", tone: "High" },
  { icon: Thermometer, label: "Avg. temperature", value: "31°C", tone: "Moderate" },
  { icon: Droplets, label: "Soil moisture", value: "74%", tone: "High" },
];

export default function RiskPrediction() {
  const current = riskTrend[riskTrend.length - 1].risk;
  const level = current > 55 ? "High" : current > 30 ? "Moderate" : "Low";
  const levelColor = level === "High" ? "text-red-600" : level === "Moderate" ? "text-soil" : "text-leaf-600";

  return (
    <ProtectedShell title="Risk Prediction">
      <div className="mb-4"><DemoTag label="Prediction based on mock weather + soil data" /></div>

      <div className="grid gap-5 lg:grid-cols-3">
        <div className="card lg:col-span-1">
          <h3 className="mb-2 font-display font-semibold text-leaf-900">Outbreak risk score</h3>
          <div className={`text-5xl font-semibold ${levelColor}`}>{current}%</div>
          <p className={`mt-1 font-medium ${levelColor}`}>{level} risk this week</p>
          <ul className="mt-4 space-y-3">
            {factors.map(({ icon: Icon, label, value, tone }) => (
              <li key={label} className="flex items-center justify-between rounded-xl bg-leaf-50 px-3 py-2">
                <span className="flex items-center gap-2 text-sm text-leaf-800"><Icon className="h-4 w-4 text-leaf-600" />{label}</span>
                <span className="text-sm font-medium text-leaf-900">{value}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="card lg:col-span-2">
          <h3 className="mb-3 font-display font-semibold text-leaf-900">7-day forecast trend</h3>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={riskTrend}>
              <defs>
                <linearGradient id="riskFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#4a9134" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#4a9134" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0f0da" />
              <XAxis dataKey="day" tick={{ fontSize: 12 }} stroke="#4a9134" />
              <YAxis tick={{ fontSize: 12 }} stroke="#4a9134" />
              <Tooltip />
              <Area type="monotone" dataKey="risk" stroke="#397527" strokeWidth={2.5} fill="url(#riskFill)" />
            </AreaChart>
          </ResponsiveContainer>
          <p className="mt-2 text-sm text-leaf-600">Risk is trending upward due to rising humidity and rainfall — consider preventive spraying before Saturday.</p>
        </div>
      </div>
    </ProtectedShell>
  );
}
