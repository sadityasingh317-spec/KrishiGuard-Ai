"use client";

import ProtectedShell from "@/components/ProtectedShell";
import { getUser } from "@/lib/auth";
import { riskTrend, cropHealth, alerts } from "@/lib/mockData";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, BarChart, Bar, CartesianGrid } from "recharts";
import { AlertTriangle, Leaf, ScanLine, TrendingUp } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { DemoUser } from "@/lib/auth";

const stats = [
  { label: "Fields monitored", value: "6", icon: Leaf },
  { label: "Scans this month", value: "23", icon: ScanLine },
  { label: "Current risk score", value: "60%", icon: TrendingUp },
  { label: "Active alerts", value: "3", icon: AlertTriangle },
];

export default function Dashboard() {
  const [user, setUser] = useState<DemoUser | null>(null);
  useEffect(() => setUser(getUser()), []);

  return (
    <ProtectedShell title="Dashboard">
      <p className="mb-5 text-leaf-700">Welcome back, <b>{user?.name ?? "Farmer"}</b> — {user?.village}</p>

      <div className="mb-6 grid grid-cols-2 gap-4 md:grid-cols-4">
        {stats.map(({ label, value, icon: Icon }) => (
          <div key={label} className="card">
            <Icon className="mb-2 h-5 w-5 text-leaf-600" />
            <div className="text-2xl font-semibold text-leaf-900">{value}</div>
            <div className="text-xs text-leaf-600">{label}</div>
          </div>
        ))}
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <div className="card">
          <h3 className="mb-3 font-display font-semibold text-leaf-900">7-day risk trend</h3>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={riskTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0f0da" />
              <XAxis dataKey="day" tick={{ fontSize: 12 }} stroke="#4a9134" />
              <YAxis tick={{ fontSize: 12 }} stroke="#4a9134" />
              <Tooltip />
              <Line type="monotone" dataKey="risk" stroke="#397527" strokeWidth={2.5} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h3 className="mb-3 font-display font-semibold text-leaf-900">Crop health overview</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={cropHealth}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e0f0da" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} stroke="#4a9134" />
              <YAxis tick={{ fontSize: 12 }} stroke="#4a9134" />
              <Tooltip />
              <Bar dataKey="healthy" fill="#4a9134" radius={[6, 6, 0, 0]} />
              <Bar dataKey="atRisk" fill="#e8c468" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="mt-5 card">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="font-display font-semibold text-leaf-900">Recent alerts</h3>
          <Link href="/alerts" className="text-sm font-medium text-leaf-600 hover:underline">View all</Link>
        </div>
        <ul className="space-y-3">
          {alerts.slice(0, 3).map((a) => (
            <li key={a.title} className="flex items-start gap-3 border-b border-leaf-50 pb-3 last:border-0 last:pb-0">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-wheat" />
              <div>
                <p className="text-sm font-medium text-leaf-900">{a.title}</p>
                <p className="text-xs text-leaf-600">{a.detail}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </ProtectedShell>
  );
}
