"use client";

import { useState } from "react";
import ProtectedShell from "@/components/ProtectedShell";
import DemoTag from "@/components/DemoTag";
import { Mic, Send, Bot, User } from "lucide-react";

interface Msg { role: "user" | "bot"; text: string; }

const canned: Record<string, string> = {
  default: "I can help with crop disease, weather risk and scheme queries. Try asking about your cotton crop.",
  cotton: "Your cotton field shows moderate leaf blight risk. Apply neem oil spray every 7 days and monitor for spreading.",
  weather: "Heavy rainfall (60mm) is expected in the next 48 hours. Delay any pesticide spraying until it clears.",
  scheme: "You're eligible for PM-KISAN and PMFBY. Visit the Government Schemes page to check application steps.",
};

function reply(input: string): string {
  const q = input.toLowerCase();
  if (q.includes("cotton") || q.includes("disease")) return canned.cotton;
  if (q.includes("weather") || q.includes("rain")) return canned.weather;
  if (q.includes("scheme") || q.includes("subsidy")) return canned.scheme;
  return canned.default;
}

export default function VoiceAssistant() {
  const [messages, setMessages] = useState<Msg[]>([{ role: "bot", text: canned.default }]);
  const [input, setInput] = useState("");
  const [listening, setListening] = useState(false);

  function send(text: string) {
    if (!text.trim()) return;
    setMessages((m) => [...m, { role: "user", text }, { role: "bot", text: reply(text) }]);
    setInput("");
  }

  function toggleMic() {
    setListening(true);
    setTimeout(() => {
      setListening(false);
      send("What is the risk for my cotton crop?");
    }, 1500);
  }

  return (
    <ProtectedShell title="Voice Assistant">
      <div className="mb-4"><DemoTag label="Voice input simulated — text chat is fully functional" /></div>
      <div className="card flex h-[60vh] flex-col">
        <div className="flex-1 space-y-3 overflow-y-auto pr-1">
          {messages.map((m, i) => (
            <div key={i} className={`flex items-start gap-2 ${m.role === "user" ? "justify-end" : ""}`}>
              {m.role === "bot" && <Bot className="mt-1 h-4 w-4 shrink-0 text-leaf-600" />}
              <div className={`max-w-[75%] rounded-2xl px-3.5 py-2 text-sm ${m.role === "user" ? "bg-leaf-600 text-white" : "bg-leaf-50 text-leaf-800"}`}>
                {m.text}
              </div>
              {m.role === "user" && <User className="mt-1 h-4 w-4 shrink-0 text-leaf-600" />}
            </div>
          ))}
        </div>
        <div className="mt-3 flex items-center gap-2 border-t border-leaf-100 pt-3">
          <button
            onClick={toggleMic}
            className={`rounded-full p-3 transition-colors ${listening ? "bg-red-500 text-white animate-pulse" : "bg-leaf-100 text-leaf-700"}`}
            aria-label="Speak"
          >
            <Mic className="h-4 w-4" />
          </button>
          <input
            className="input"
            placeholder="Type your question (English / Hindi)"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send(input)}
          />
          <button onClick={() => send(input)} className="btn-primary !px-3 !py-3"><Send className="h-4 w-4" /></button>
        </div>
      </div>
    </ProtectedShell>
  );
}
