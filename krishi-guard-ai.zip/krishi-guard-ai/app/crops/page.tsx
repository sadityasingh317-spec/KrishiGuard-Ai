"use client";

import { useState } from "react";
import ProtectedShell from "@/components/ProtectedShell";
import DemoTag from "@/components/DemoTag";
import { crops } from "@/lib/mockData";
import { Sprout, CheckCircle2 } from "lucide-react";

export default function Crops() {
  const [sold, setSold] = useState<number[]>([]);

  return (
    <ProtectedShell title="Crops">
      <div className="mb-4"><DemoTag label="Procurement request is simulated" /></div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {crops.map((c) => (
          <div key={c.id} className="card">
            <div className="mb-2 flex items-center gap-2">
              <div className="rounded-lg bg-leaf-100 p-2"><Sprout className="h-4 w-4 text-leaf-700" /></div>
              <div>
                <h3 className="font-display font-semibold text-leaf-900">{c.name}</h3>
                <p className="text-xs text-leaf-500">{c.variety}</p>
              </div>
            </div>
            <p className="text-sm text-leaf-700">Stage: <b>{c.stage}</b></p>
            <p className="text-sm text-leaf-700">Market price: <b>₹{c.price.toLocaleString("en-IN")}</b>/{c.unit}</p>
            {sold.includes(c.id) ? (
              <div className="btn-outline mt-3 flex w-full items-center justify-center gap-2 !text-leaf-600">
                <CheckCircle2 className="h-4 w-4" /> Request sent
              </div>
            ) : (
              <button onClick={() => setSold((s) => [...s, c.id])} className="btn-primary mt-3 w-full">
                Request procurement
              </button>
            )}
          </div>
        ))}
      </div>
    </ProtectedShell>
  );
}
