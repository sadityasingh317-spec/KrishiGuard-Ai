"use client";

import ProtectedShell from "@/components/ProtectedShell";
import { alerts } from "@/lib/mockData";
import { AlertTriangle, AlertOctagon, Info } from "lucide-react";

const iconMap: Record<string, any> = { Critical: AlertOctagon, Warning: AlertTriangle, Info: Info };
const colorMap: Record<string, string> = {
  Critical: "bg-red-100 text-red-700",
  Warning: "bg-wheat/40 text-soil",
  Info: "bg-leaf-100 text-leaf-700",
};

export default function Alerts() {
  return (
    <ProtectedShell title="Alerts">
      <div className="space-y-3">
        {alerts.map((a) => {
          const Icon = iconMap[a.level];
          return (
            <div key={a.title} className="card flex items-start gap-3">
              <div className={`rounded-lg p-2 ${colorMap[a.level]}`}><Icon className="h-4 w-4" /></div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-leaf-900">{a.title}</h3>
                  <span className="text-xs text-leaf-400">{a.time}</span>
                </div>
                <p className="mt-1 text-sm text-leaf-700">{a.detail}</p>
                <span className={`badge mt-2 ${colorMap[a.level]}`}>{a.level}</span>
              </div>
            </div>
          );
        })}
      </div>
    </ProtectedShell>
  );
}
