"use client";

import ProtectedShell from "@/components/ProtectedShell";
import { hotspots } from "@/lib/mockData";
import { MapPinned } from "lucide-react";

const riskColor: Record<string, string> = {
  High: "bg-red-100 text-red-700",
  Moderate: "bg-wheat/40 text-soil",
  Low: "bg-leaf-100 text-leaf-700",
};

export default function Hotspots() {
  return (
    <ProtectedShell title="Hotspots">
      <div className="grid gap-4 md:grid-cols-2">
        {hotspots.map((h) => (
          <div key={h.region} className="card">
            <div className="mb-2 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MapPinned className="h-4 w-4 text-leaf-600" />
                <h3 className="font-display font-semibold text-leaf-900">{h.region}</h3>
              </div>
              <span className={`badge ${riskColor[h.risk]}`}>{h.risk} risk</span>
            </div>
            <p className="text-sm text-leaf-700">Reported disease: <b>{h.disease}</b></p>
            <p className="text-sm text-leaf-700">Active cases: <b>{h.cases}</b></p>
          </div>
        ))}
      </div>
      <div className="card mt-5 flex h-52 items-center justify-center text-sm text-leaf-500">
        Interactive hotspot map (demo placeholder)
      </div>
    </ProtectedShell>
  );
}
