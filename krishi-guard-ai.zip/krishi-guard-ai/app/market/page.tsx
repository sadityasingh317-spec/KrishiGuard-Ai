"use client";

import ProtectedShell from "@/components/ProtectedShell";
import { marketPrices } from "@/lib/mockData";
import { ArrowUpRight, ArrowDownRight } from "lucide-react";

export default function Market() {
  return (
    <ProtectedShell title="Market">
      <div className="card overflow-x-auto">
        <table className="w-full min-w-[480px] text-sm">
          <thead>
            <tr className="border-b border-leaf-100 text-left text-leaf-500">
              <th className="pb-2 font-medium">Crop</th>
              <th className="pb-2 font-medium">Mandi</th>
              <th className="pb-2 font-medium">Price (₹/quintal)</th>
              <th className="pb-2 font-medium">24h change</th>
            </tr>
          </thead>
          <tbody>
            {marketPrices.map((m) => (
              <tr key={m.crop} className="border-b border-leaf-50 last:border-0">
                <td className="py-3 font-medium text-leaf-900">{m.crop}</td>
                <td className="py-3 text-leaf-700">{m.mandi}</td>
                <td className="py-3 text-leaf-700">₹{m.price.toLocaleString("en-IN")}</td>
                <td className={`py-3 flex items-center gap-1 ${m.change >= 0 ? "text-leaf-600" : "text-red-500"}`}>
                  {m.change >= 0 ? <ArrowUpRight className="h-4 w-4" /> : <ArrowDownRight className="h-4 w-4" />}
                  {Math.abs(m.change)}%
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-xs text-leaf-500">Prices are illustrative mock data, updated for demo purposes only.</p>
    </ProtectedShell>
  );
}
