"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import ProtectedShell from "@/components/ProtectedShell";
import DemoTag from "@/components/DemoTag";
import { getUser, logout, DemoUser } from "@/lib/auth";
import { UserCircle2, Phone, MapPin, Sprout, LogOut } from "lucide-react";

export default function Profile() {
  const [user, setUser] = useState<DemoUser | null>(null);
  const router = useRouter();

  useEffect(() => setUser(getUser()), []);

  return (
    <ProtectedShell title="Profile">
      <div className="mb-4"><DemoTag label="Demo account — data is not saved" /></div>
      <div className="card max-w-lg">
        <div className="mb-5 flex items-center gap-4">
          <div className="rounded-full bg-leaf-100 p-4"><UserCircle2 className="h-9 w-9 text-leaf-700" /></div>
          <div>
            <h2 className="font-display text-lg font-semibold text-leaf-900">{user?.name ?? "—"}</h2>
            <p className="text-sm text-leaf-500">Farmer account</p>
          </div>
        </div>
        <div className="space-y-3 text-sm">
          <p className="flex items-center gap-2 text-leaf-800"><Phone className="h-4 w-4 text-leaf-500" /> {user?.mobile}</p>
          <p className="flex items-center gap-2 text-leaf-800"><MapPin className="h-4 w-4 text-leaf-500" /> {user?.village}</p>
          <p className="flex items-center gap-2 text-leaf-800"><Sprout className="h-4 w-4 text-leaf-500" /> {user?.crops.join(", ")}</p>
        </div>
        <button
          onClick={() => { logout(); router.push("/login"); }}
          className="btn-outline mt-6 flex w-full items-center justify-center gap-2 !text-red-600 !border-red-200 hover:!bg-red-50"
        >
          <LogOut className="h-4 w-4" /> Logout
        </button>
      </div>
    </ProtectedShell>
  );
}
