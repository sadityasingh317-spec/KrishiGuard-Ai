"use client";

import ProtectedShell from "@/components/ProtectedShell";
import { schemes } from "@/lib/mockData";
import { Landmark, CalendarClock, Users2 } from "lucide-react";

export default function Schemes() {
  return (
    <ProtectedShell title="Government Schemes">
      <div className="grid gap-4 md:grid-cols-2">
        {schemes.map((s) => (
          <div key={s.name} className="card">
            <div className="mb-2 flex items-center gap-2">
              <div className="rounded-lg bg-leaf-100 p-2"><Landmark className="h-4 w-4 text-leaf-700" /></div>
              <h3 className="font-display font-semibold text-leaf-900">{s.name}</h3>
            </div>
            <p className="text-sm text-leaf-700">{s.desc}</p>
            <div className="mt-3 space-y-1.5 text-xs text-leaf-600">
              <p className="flex items-center gap-1.5"><Users2 className="h-3.5 w-3.5" /> {s.eligibility}</p>
              <p className="flex items-center gap-1.5"><CalendarClock className="h-3.5 w-3.5" /> {s.deadline}</p>
            </div>
            <button className="btn-outline mt-3 w-full">Check eligibility</button>
          </div>
        ))}
      </div>
    </ProtectedShell>
  );
}
