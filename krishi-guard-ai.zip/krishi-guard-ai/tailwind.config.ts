import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        leaf: {
          50: "#f2f8f0",
          100: "#e0f0da",
          200: "#c0e0b3",
          400: "#6fb254",
          500: "#4a9134",
          600: "#397527",
          700: "#2c5b1f",
          800: "#1f4416",
          900: "#152f0f",
        },
        soil: "#7a5230",
        wheat: "#e8c468",
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        display: ["Poppins", "system-ui", "sans-serif"],
      },
      boxShadow: {
        card: "0 1px 2px rgba(21,47,15,0.06), 0 4px 14px rgba(21,47,15,0.06)",
      },
    },
  },
  plugins: [],
};
export default config;
