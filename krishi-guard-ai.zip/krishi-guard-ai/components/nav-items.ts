import {
  LayoutDashboard, ScanLine, TrendingUp, Leaf, Mic, Sprout,
  Landmark, ShoppingCart, Users, MapPinned, Bell, UserCircle,
} from "lucide-react";
import { DictKey } from "@/lib/i18n";

export const navItems: { href: string; icon: any; label: DictKey }[] = [
  { href: "/dashboard", icon: LayoutDashboard, label: "dashboard" },
  { href: "/disease-detection", icon: ScanLine, label: "diseaseDetection" },
  { href: "/risk-prediction", icon: TrendingUp, label: "riskPrediction" },
  { href: "/recommendations", icon: Leaf, label: "recommendations" },
  { href: "/voice-assistant", icon: Mic, label: "voiceAssistant" },
  { href: "/crops", icon: Sprout, label: "crops" },
  { href: "/schemes", icon: Landmark, label: "schemes" },
  { href: "/market", icon: ShoppingCart, label: "market" },
  { href: "/expert-help", icon: Users, label: "expertHelp" },
  { href: "/hotspots", icon: MapPinned, label: "hotspots" },
  { href: "/alerts", icon: Bell, label: "alerts" },
  { href: "/profile", icon: UserCircle, label: "profile" },
];
