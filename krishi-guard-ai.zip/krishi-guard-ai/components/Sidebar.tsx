"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Sprout as Logo } from "lucide-react";
import { navItems } from "./nav-items";
import { useLang } from "./LanguageProvider";

export default function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();
  const { t } = useLang();

  return (
    <nav className="flex h-full w-64 flex-col bg-white border-r border-leaf-100">
      <Link href="/dashboard" className="flex items-center gap-2 px-5 py-5 border-b border-leaf-100">
        <div className="rounded-xl bg-leaf-600 p-2"><Logo className="h-5 w-5 text-white" /></div>
        <span className="font-display font-semibold text-leaf-800">{t("appName")}</span>
      </Link>
      <div className="flex-1 overflow-y-auto py-3">
        {navItems.map(({ href, icon: Icon, label }) => {
          const active = pathname === href;
          return (
            <Link
              key={href}
              href={href}
              onClick={onNavigate}
              className={`mx-3 mb-1 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
                active ? "bg-leaf-600 text-white" : "text-leaf-800 hover:bg-leaf-50"
              }`}
            >
              <Icon className="h-4 w-4 shrink-0" />
              {t(label)}
            </Link>
          );
        })}
      </div>
      <div className="p-4 text-xs text-leaf-500 border-t border-leaf-100">SIH 2026 · PS 26131</div>
    </nav>
  );
}
