export default function DemoTag({ label = "Demo" }: { label?: string }) {
  return <span className="demo-tag">{label}</span>;
}
