"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { dict, DictKey, Lang } from "@/lib/i18n";

interface Ctx {
  lang: Lang;
  toggle: () => void;
  t: (key: DictKey) => string;
}

const LanguageContext = createContext<Ctx | null>(null);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLang] = useState<Lang>("en");

  useEffect(() => {
    const saved = localStorage.getItem("kg_lang") as Lang | null;
    if (saved === "en" || saved === "hi") setLang(saved);
  }, []);

  const toggle = () => {
    const next: Lang = lang === "en" ? "hi" : "en";
    setLang(next);
    localStorage.setItem("kg_lang", next);
  };

  const t = (key: DictKey) => dict[lang][key];

  return (
    <LanguageContext.Provider value={{ lang, toggle, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLang() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLang must be used within LanguageProvider");
  return ctx;
}
