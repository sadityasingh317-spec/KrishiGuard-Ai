"use client";

import { Menu, Languages, LogOut, Bell } from "lucide-react";
import { useRouter } from "next/navigation";
import { useLang } from "./LanguageProvider";
import { logout } from "@/lib/auth";

export default function Topbar({ title, onMenu }: { title: string; onMenu: () => void }) {
  const { lang, toggle } = useLang();
  const router = useRouter();

  return (
    <header className="sticky top-0 z-20 flex items-center justify-between border-b border-leaf-100 bg-white/90 backdrop-blur px-4 py-3 md:px-6">
      <div className="flex items-center gap-3">
        <button onClick={onMenu} className="md:hidden rounded-lg p-2 hover:bg-leaf-50" aria-label="Open menu">
          <Menu className="h-5 w-5 text-leaf-800" />
        </button>
        <h1 className="font-display text-lg font-semibold text-leaf-900">{title}</h1>
      </div>
      <div className="flex items-center gap-2">
        <button onClick={toggle} className="btn-outline flex items-center gap-1.5 !px-3 !py-1.5 text-sm">
          <Languages className="h-4 w-4" /> {lang === "en" ? "हिंदी" : "English"}
        </button>
        <button
          onClick={() => router.push("/alerts")}
          className="rounded-lg p-2 hover:bg-leaf-50 relative"
          aria-label="Alerts"
        >
          <Bell className="h-5 w-5 text-leaf-800" />
          <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-red-500" />
        </button>
        <button
          onClick={() => { logout(); router.push("/login"); }}
          className="btn-outline flex items-center gap-1.5 !px-3 !py-1.5 text-sm"
        >
          <LogOut className="h-4 w-4" /> Logout
        </button>
      </div>
    </header>
  );
}
