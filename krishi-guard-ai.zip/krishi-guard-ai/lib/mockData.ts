export const riskTrend = [
  { day: "Mon", risk: 22 },
  { day: "Tue", risk: 28 },
  { day: "Wed", risk: 35 },
  { day: "Thu", risk: 48 },
  { day: "Fri", risk: 41 },
  { day: "Sat", risk: 55 },
  { day: "Sun", risk: 60 },
];

export const cropHealth = [
  { name: "Cotton", healthy: 72, atRisk: 28 },
  { name: "Soybean", healthy: 85, atRisk: 15 },
  { name: "Wheat", healthy: 91, atRisk: 9 },
  { name: "Sugarcane", healthy: 64, atRisk: 36 },
];

export const diseaseResults = [
  {
    disease: "Leaf Blight",
    confidence: 87,
    severity: "Moderate",
    crop: "Cotton",
    symptoms: "Brown lesions with yellow halo spreading from leaf margins.",
  },
  {
    disease: "Powdery Mildew",
    confidence: 79,
    severity: "Low",
    crop: "Wheat",
    symptoms: "White powdery patches on upper leaf surface.",
  },
  {
    disease: "Root Rot",
    confidence: 91,
    severity: "High",
    crop: "Soybean",
    symptoms: "Wilting, yellowing and blackened root tissue.",
  },
];

export const recommendations = {
  organic: [
    "Apply neem oil spray (5ml/L) every 7 days",
    "Introduce Trichoderma-based bio-fungicide to soil",
    "Remove and burn infected plant debris",
    "Rotate with non-host legumes next season",
  ],
  ipm: [
    "Install pheromone traps at 5 per acre",
    "Release Trichogramma cards for pest control",
    "Use resistant seed varieties for next sowing",
    "Maintain field sanitation and proper spacing",
  ],
};

export const crops = [
  { id: 1, name: "Cotton", variety: "Bt Cotton", stage: "Flowering", price: 6800, unit: "quintal" },
  { id: 2, name: "Soybean", variety: "JS-335", stage: "Pod filling", price: 4650, unit: "quintal" },
  { id: 3, name: "Wheat", variety: "HD-2967", stage: "Harvested", price: 2275, unit: "quintal" },
  { id: 4, name: "Sugarcane", variety: "Co-86032", stage: "Growth", price: 340, unit: "quintal" },
  { id: 5, name: "Turmeric", variety: "Salem", stage: "Harvested", price: 15200, unit: "quintal" },
];

export const schemes = [
  {
    name: "PM-KISAN",
    desc: "Income support of ₹6,000/year to eligible farmer families.",
    eligibility: "All landholding farmer families",
    deadline: "Rolling",
  },
  {
    name: "PMFBY (Fasal Bima Yojana)",
    desc: "Crop insurance against natural calamities, pests and diseases.",
    eligibility: "Farmers growing notified crops",
    deadline: "Before sowing season",
  },
  {
    name: "Soil Health Card Scheme",
    desc: "Free soil testing and nutrient recommendation every 2 years.",
    eligibility: "All farmers",
    deadline: "Ongoing",
  },
  {
    name: "Kisan Credit Card",
    desc: "Low-interest credit for crop and allied agricultural needs.",
    eligibility: "Farmers, tenant farmers, SHGs",
    deadline: "Ongoing",
  },
];

export const marketPrices = [
  { crop: "Cotton", mandi: "Wardha", price: 6800, change: 2.3 },
  { crop: "Soybean", mandi: "Amravati", price: 4650, change: -1.1 },
  { crop: "Wheat", mandi: "Nagpur", price: 2275, change: 0.6 },
  { crop: "Turmeric", mandi: "Sangli", price: 15200, change: 4.2 },
  { crop: "Onion", mandi: "Lasalgaon", price: 1850, change: -3.5 },
];

export const experts = [
  { name: "Dr. Anjali Deshmukh", role: "Plant Pathologist", exp: "12 yrs", available: true },
  { name: "Suresh Rao", role: "Agronomist", exp: "8 yrs", available: true },
  { name: "Dr. Vikram Joshi", role: "Soil Scientist", exp: "15 yrs", available: false },
];

export const hotspots = [
  { region: "Wardha Taluka", disease: "Leaf Blight", cases: 142, risk: "High" },
  { region: "Yavatmal District", disease: "Root Rot", cases: 89, risk: "Moderate" },
  { region: "Amravati Belt", disease: "Powdery Mildew", cases: 54, risk: "Low" },
  { region: "Nagpur Rural", disease: "Aphid Infestation", cases: 118, risk: "High" },
];

export const alerts = [
  { title: "Heavy rainfall expected", detail: "60mm rain forecast in next 48 hours — delay pesticide spray.", level: "Warning", time: "2h ago" },
  { title: "Leaf Blight outbreak nearby", detail: "Cases rising in Wardha Taluka, inspect cotton fields.", level: "Critical", time: "5h ago" },
  { title: "Subsidy application closing soon", detail: "PMFBY enrollment closes in 4 days.", level: "Info", time: "1d ago" },
];
