export interface DemoUser {
  name: string;
  mobile: string;
  village: string;
  crops: string[];
}

const AUTH_KEY = "kg_auth_user";
export const DEMO_MOBILE = "9999999999";
export const DEMO_PASSWORD = "demo123";

export function login(mobile: string, password: string): boolean {
  if (mobile === DEMO_MOBILE && password === DEMO_PASSWORD) {
    const user: DemoUser = {
      name: "Ramesh Patil",
      mobile,
      village: "Wardha, Maharashtra",
      crops: ["Cotton", "Soybean", "Wheat"],
    };
    localStorage.setItem(AUTH_KEY, JSON.stringify(user));
    return true;
  }
  return false;
}

export function logout() {
  localStorage.removeItem(AUTH_KEY);
}

export function getUser(): DemoUser | null {
  if (typeof window === "undefined") return null;
  const raw = localStorage.getItem(AUTH_KEY);
  return raw ? (JSON.parse(raw) as DemoUser) : null;
}

export function isLoggedIn(): boolean {
  return getUser() !== null;
}
